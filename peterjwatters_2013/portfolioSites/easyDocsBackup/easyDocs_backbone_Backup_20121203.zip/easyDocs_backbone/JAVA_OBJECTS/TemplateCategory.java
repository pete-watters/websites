/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nextec.client.minimodel.template.category;

/**
 *
 * @author patrickfmonaghan
 */
public enum TemplateCategory {
    CompanyDocument,
    JobDocument,
    EmployeeDocument    // TODO: These are just samples
    
}
