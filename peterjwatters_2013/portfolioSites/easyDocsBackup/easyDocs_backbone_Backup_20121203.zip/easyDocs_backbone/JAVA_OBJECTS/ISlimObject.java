package com.nextec.client.minimodel.base;

import com.google.gwt.user.client.rpc.IsSerializable;



/**
 * Nextec Software
 * @author Patrick Monaghan <Patrick Monaghan at Nextec Software>
 */
public interface ISlimObject extends java.io.Serializable {
//public interface ISlimObject extends IsSerializable {

}
