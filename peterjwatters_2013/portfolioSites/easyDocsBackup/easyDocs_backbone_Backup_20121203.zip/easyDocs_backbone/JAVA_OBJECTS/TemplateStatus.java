package com.nextec.client.minimodel.template.status;

/**
 *
 * @author patrickfmonaghan
 */
public enum TemplateStatus {
    Active,
    Suspended,
    Deleted // TODO: Fill this out properly
    
}
