var welcomeMessage_Data = { name: "Pete", welcomeMessage:"The home of easy, painless paperwork!"} ;


// var breadCrumb_Data = { breadcrumb: ' <span class="divider">/</span></li><li class="active"><a href="#">Dashboard</a>'} ;

var breadCrumb_Data = { breadcrumb: ''} ;
	
var clientQuestionData = [
						{id: 1, title : "Question 1", answered_by : "Alan Hayes", date : "20/07/2007", answer: "This is your answer"},
						{id: 2, title : "Question 1", answered_by : "Patrick Monaghan", date : "20/07/2007", answer: "This is your answer"},
						{id: 3, title : "Question 1", answered_by : "Peter Watters", date : "20/07/2012", answer: "This is your answer"},
						{id: 4, title : "Question 1", answered_by : "Alan Hayes", date : "20/07/2007", answer: "This is your answer"},
						{id: 5, title : "Question 1", answered_by : "Alan Hayes", date : "20/07/2012", answer: "This is your answer"},
						{id: 6, title : "Question 1", answered_by : "Alan Hayes", date : "20/07/2007", answer: "This is your answer"},
						{id: 7, title : "Question 1", answered_by : "Peter Watters", date : "20/07/2012", answer: "This is your answer"}

						];



var clientInfoData = [
		{
			id: 1,
			name: "Peter Watters",
			company: "Nova LTD",
			lastGenerateDocument: "document",
			documentCount: 154,
			favouriteCount: 248,
			reportedCount: 412,
			profilePicture: ""
		}

		];

var clientDocumentData = [
                  { id: 1, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/2.jpg"},
                  { id: 2, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/3.jpg"},
                  { id: 3, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/4.jpg"},
                  { id: 4, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/5.jpg"},
                  { id: 5, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/6.jpg"}
                  ];
var popularTemplatesData = [
                  { id: 1, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", popularity : "Very Popular", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/2.jpg"},
                  { id: 2, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", popularity : "Very Popular", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/3.jpg"},
                  { id: 3, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", popularity : "Very Popular", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/4.jpg"},
                  { id: 4, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", popularity : "Very Popular", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/5.jpg"},
                  { id: 5, title: "Lorem ipsum dolor sit ames", description: "Vestibulum dictum adipiscing dolor amauris libero, venenatis", creator:"pete", partner:"ESA",downloads:"34", popularity : "Very Popular", thumbnailAlt:"thumbnail", thumbnailLink:"images/thumbs/6.jpg"}
                  ];

var easyDocsOBJ = 
			[{"nextec_client" : {

						     "SlimTemplate" :{    
						         "id" : 1,
							      "title" : "",
							      "description" : "",
							      "generatedCount" : "",
							      "partnerCompany" : "",
							      "currentVersion" : "",
							      "draftVersion" : "",
							      "status" : "",
							      "category" : ""
						    },

						      "SlimCompany" : {
									       "id" : "1",
									       "name" : "",
									       "mail" : "",
									       "shortCode" : "",
									       "docDownloadPasswordProtected" : "",
									       "docPassword" : "",
									       "defaultUserProvided" : "",
									       "defaultUserFullName" : "",
									       "defaultUsername" : "",
									       "defaultUserPassword" : "",
									       "type" : "",
									       "status" : "",
									       "logo" : ""
							  },

							 "SlimImage" : {
							     "id" : "",
							     "fileName" : "",
							     "url" : "",
							     "company" : ""
							 },

						  	 "TemplateCategory" : {
							    "CompanyDocument" : "",
							    "JobDocument" : "",
							    "EmployeeDocument" : ""   
						    },

						  	 "TemplateStatus" : {
							    "Active" : "",
							    "Suspended" : "",
							    "Deleted" : "" 
							}
			}
			}]


var populateEasyDocsOBJ = function(){

}

var populateEasyDocs_SlimTemplateOBJ = function( id,title,description,generatedCount,partnerCompany,currentVersion,draftVersion,category){

						   [{"SlimTemplate" :{    
						         "id" : 1,
							      "title" : "",
							      "description" : "",
							      "generatedCount" : "",
							      "partnerCompany" : "",
							      "currentVersion" : "",
							      "draftVersion" : "",
							      "status" : "",
							      "category" : ""
						    }
}]  
}


