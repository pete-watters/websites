[{"nextec_client" : {

			     "SlimTemplate" :{    
			         "id" = "",
				      "title" = "",
				      "description" = "",
				      "generatedCount" = "",
				      "partnerCompany" = "",
				      "currentVersion" = "",
				      "draftVersion" = "",
				      "status" = "",
				      "category" = ""
			    },
			      "SlimCompany" : {
						       "id" = "1",
						       "name" = "",
						       "mail" = "",
						       "shortCode" = "",
						       "docDownloadPasswordProtected" = "",
						       "docPassword" = "",
						       "defaultUserProvided" = "",
						       "defaultUserFullName" = "",
						       "defaultUsername" = "",
						       "defaultUserPassword" = "",
						       "type" = "",
						       "status" = "",
						       "logo" = ""
				  },

			  	 "TemplateCategory" : {
				    "CompanyDocument" = "",
				    "JobDocument" = "",
				    "EmployeeDocument" = ""   
			    },

			  	 "TemplateStatus" : {
				    "Active" = "",
				    "Suspended" = "",
				    "Deleted" = "" 
				},

				 "SlimImage" : {
				     "id" = "",
				     "fileName" = "",
				     "url" = "",
				     "company" = ""
				 }
}
}]