[{"nextec_client" : {

				  "SlimTemplate" :{    
								         "id" = "1",
									      "title" = "Document 1",
									      "description" = "My first document",
									      "generatedCount" = "2",
									      "partnerCompany" = "Nextec",
									      "currentVersion" = "1.9.0",
									      "draftVersion" = "1.9.1",
									      "status" = "ACTIVE",
									      "category" = "Test"
				    					},
			      "SlimCompany" : {
									       "id" = "1",
									       "name" = "Nextec",
									       "mail" = "mail@nextec.com",
									       "shortCode" = "NXT",
									       "docDownloadPasswordProtected" = "no",
									       "docPassword" = "",
									       "defaultUserProvided" = "user",
									       "defaultUserFullName" = "Test User",
									       "defaultUsername" = "test",
									       "defaultUserPassword" = "test",
									       "type" = "Test",
									       "status" = "ACTIVE",
									       "logo" = "1"
				  					},

					"SlimImage" : {
									     "id" = "1",
									     "fileName" = "logo.gif",
									     "url" = "../../images/",
									     "company" = "Nextec"
							 },

					"TemplateCategory" : {
										    "CompanyDocument" = "Nextec Doc",
										    "JobDocument" = "easyDocs Release 1.0",
										    "EmployeeDocument" = ""   
						    			},

					"TemplateStatus" : {
										    "Active" = "true",
										    "Suspended" = "false",
										    "Deleted" = "false" 
										}
			}
			}]