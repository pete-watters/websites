require( [ "jquery", 

			"js/bootstrap.min.js",
			"js/questions-flow.js",
			"js/jquery.qtip.js",
			"js/jquery-ui-1.8.21.custom.min.js",
			"js/applicationSetup.js",

			"jqueryFunctions/jquery.alpha", 
			"jqueryFunctions/jquery.beta", 
			"jqueryFunctions/jquery.pete",
			"jqueryFunctions/easydocs.loginMenu",
			"jqueryFunctions/easydocs.workbench"
			], function($) {
   
					    //the jquery.alpha.js and jquery.beta.js plugins have been loaded.
					    $(function() {
					        $('body').alpha().beta().pete();


							$("#menu").loginMenu();


						//\	$("#workbench").workbench();

					    });
});
