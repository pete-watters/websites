$(function(){
    //Show subquestions 
	     $('.form-radiobtns input').click(function(){
		    var getId = $(this).attr("id");
			var getClass = $(this).attr("class");
			 if(getId == getClass+'-subquestions'){
			  $('.'+getClass+'-showsubquestions').slideDown();
			 } else {
			  $('.'+getClass+'-showsubquestions').slideUp();
			  }
		 });
		 
// Set width for numeric 
  $('input[type="text"]').each(function(index) {
     var getIalt = $(this).attr("alt");
	 if (getIalt == "numeric") {
	 $(this).css("width", "200px");
	 }
	});
	
    //reset progress bar
    $('.progress').css('width','0');
    $('.progress_text').html('0% Complete');

    //first_step
    $('form').submit(function(){ return false; });
    $('.submit_first').click(function(){
      
                //update progress bar
                $('.progress_text').html('33% Complete');
                $('.progress').animate({ width: '33%'}, 1000);
                
                //slide steps
                $('.first_step').hide("slow");
                $('.second_step').show();     

            
    });

 //second_step
    $('.submit_second').click(function(){
		 		 
	  var counter = 0;
	  
     //Loop through second step text inputs and see if they're not empty
	 $('.second_step input[type="text"]').each(function(index) {

     var getvalues = $(this).val();
	 var myClass = $(this).attr("class");
	 		 
		 
     if(getvalues == '' || getvalues == 'Answer goes here...'){	
	 $('.'+myClass).css("border", "1px solid red");
     $('.'+myClass).effect("shake", { times:3, distance:9}, 100);
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show();

	 counter++;	 
	} else {
	
	//Check if number
	var getAlt = $('.'+myClass).attr('alt'); 
	 if(getAlt == 'numeric') {
     var myInteger = parseInt(getvalues);
      if(myInteger >= 0) {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show();
  } else {
 	 $('.'+myClass).css("border", "1px solid red");
     $('.'+myClass).effect("shake", { times:3, distance:9}, 100);
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show(); 
	  counter++;	
  }
 } else {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show(); 
 
 }
}
	});

//Loop through second step radio inputs and see if they're checked
	 $('.second_step input[type="radio"]').each(function(index) {
     var myName = $(this).attr("name");
	 var myClass = $(this).attr("class");
	 
     if (!$("input[name="+myName+"]:checked").val()) {
          $(this).parent().fadeOut();
          $(this).parent().fadeIn();
	      $(this).parent().fadeOut();
          $(this).parent().fadeIn();
		  $(this).parent().fadeOut();
          $(this).parent().fadeIn();
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show();
 
	 counter++;
	} else {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show();
}
	});

	
	
	if(counter==0){
                //update progress bar
                $('.progress_text').html('66% Complete');
                $('.progress').animate({ width: '66%'}, 1000);
                
                //slide steps
                $('.second_step').slideUp();
                $('.third_step').slideDown(); 
   }
    });
	
	

//third_step
    $('.submit_third').click(function(){
		  var counter = 0;
	  
     //Loop through third step text inputs and see if the're not empty
	 $('.third_step input[type="text"]').each(function(index) {

     var getvalues = $(this).val();
	 var myClass = $(this).attr("class");
	 
     if(getvalues == '' || getvalues == 'Answer goes here...'){	
	 $('.'+myClass).css("border", "1px solid red");
     $('.'+myClass).effect("shake", { times:3, distance:9}, 100);
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show();

	 counter++;	 
	} else {
	
	//Check if number
	var getAlt = $('.'+myClass).attr('alt'); 
	 if(getAlt == 'numeric') {
     var myInteger = parseInt(getvalues);
      if(myInteger >= 0) {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show();
  } else {
 	 $('.'+myClass).css("border", "1px solid red");
     $('.'+myClass).effect("shake", { times:3, distance:9}, 100);
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show(); 
	  counter++;	
  }
 } else {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show(); 
 
 }
}
	});

//Loop through third step radio inputs and see if they're checked
	 $('.third_step input[type="radio"]').each(function(index) {
     var myName = $(this).attr("name");
	 var myClass = $(this).attr("class");
	 
     if (!$("input[name="+myName+"]:checked").val()) {
          $(this).parent().fadeOut();
          $(this).parent().fadeIn();
	      $(this).parent().fadeOut();
          $(this).parent().fadeIn();
		  $(this).parent().fadeOut();
          $(this).parent().fadeIn();
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show();
 
	 counter++;
	} else {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show();
}
	});

	
	
	if(counter==0){
        //update progress bar
        $('.progress_text').html('100% Complete');
        $('.progress').animate({ width: '100%'}, 1000);

        //slide steps
        $('.third_step').slideUp();
        $('.fourth_step').slideDown();  
		
   }          
    });


    $('.submit_fourth').click(function(){
			  var counter = 0;
	  
     //Loop through fourth step text inputs and see if the're not empty
	 $('.fourth_step input[type="text"]').each(function(index) {

     var getvalues = $(this).val();
	 var myClass = $(this).attr("class");
	 
     if(getvalues == '' || getvalues == 'Answer goes here...'){	
	 $('.'+myClass).css("border", "1px solid red");
     $('.'+myClass).effect("shake", { times:3, distance:9}, 100);
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show();

	 counter++;	 
	} else {
	
	//Check if number
	var getAlt = $('.'+myClass).attr('alt'); 
	 if(getAlt == 'numeric') {
     var myInteger = parseInt(getvalues);
      if(myInteger >= 0) {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show();
  } else {
 	 $('.'+myClass).css("border", "1px solid red");
     $('.'+myClass).effect("shake", { times:3, distance:9}, 100);
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show(); 
	  counter++;	
  }
 } else {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show(); 
 
 }
}
	});

//Loop through fourth step radio inputs and see if they're checked
	 $('.fourth_step input[type="radio"]').each(function(index) {
     var myName = $(this).attr("name");
	 var myClass = $(this).attr("class");
	 
     if (!$("input[name="+myName+"]:checked").val()) {
          $(this).parent().fadeOut();
          $(this).parent().fadeIn();
	      $(this).parent().fadeOut();
          $(this).parent().fadeIn();
		  $(this).parent().fadeOut();
          $(this).parent().fadeIn();
	 $('#valid-'+myClass).hide();
	 $('#invalid-'+myClass).show();
 
	 counter++;
	} else {
	$('input.'+myClass).css("border", "1px solid green");
	$('#invalid-'+myClass).hide();
	$('#valid-'+myClass).show();
}
	});

	
	
	if(counter==0){
        //update progress bar
        $('.progress_text').html('90% Complete');
        $('.progress').animate({ width: '90%'}, 1000);

          //slide steps
              $('.fourth_step').slideUp();
			  $('#topsection').hide();
              $('.final_step').slideDown(); 
			  
		
   }
    });
	
// Custom Radio Buttons
$('.form-radiobtns span').click(function(){
$('.form-radiobtns span').removeClass('checked');
$(this).addClass('checked');
});

// Custom check boxes
$('.check-bg').click(function(){
if($(this).hasClass('check-bg checked-box')) {
$(this).removeClass('checked-box');
} else {
$(this).addClass('checked-box');
}
});
});