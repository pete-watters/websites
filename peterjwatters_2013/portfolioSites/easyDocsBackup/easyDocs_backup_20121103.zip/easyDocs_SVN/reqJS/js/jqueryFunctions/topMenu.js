$.fn.topMenu = function() {
    return this.append('<p>pete is Go!</p>');
};