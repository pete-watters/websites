$.fn.loginMenu = function() {
 
 				var TopUserMenu = '<div id="loggedin">Logged in: <span id="username">Peter Watters</span><div class="middleline"></div>' 
									+ '</div><a href="" title="Logout" class="logout">Logout <img src="images/logout.png" alt="Logout"></a>';

				return this.html(TopUserMenu);

};