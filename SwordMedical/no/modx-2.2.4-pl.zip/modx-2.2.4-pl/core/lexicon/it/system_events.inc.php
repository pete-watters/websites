<?php
/**
 * System Events Italian lexicon topic
 *
 * @language it 
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Pulisci';
$_lang['error_log'] = 'Log Errori';
$_lang['error_log_desc'] = 'Qui trovi i log degli errori di MODX Revolution:';
$_lang['system_events'] = 'Eventi di Sistema';
$_lang['priority'] = 'Priorità';