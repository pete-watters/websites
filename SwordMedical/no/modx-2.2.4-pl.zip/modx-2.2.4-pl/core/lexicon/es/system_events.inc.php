﻿<?php
/**
 * System Events Spanish lexicon topic
 *
 * @language es_MX
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Limpiar';
$_lang['error_log'] = 'Bitácora de Errores';
$_lang['error_log_desc'] = 'Aquí está la bitácora de errores para MODX Revolution:';
$_lang['system_events'] = 'Eventos del Sistema';
$_lang['priority'] = 'Prioridad';